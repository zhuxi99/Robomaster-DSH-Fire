import type { Context } from '@deepseek-ai/cordis';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { Config } from './config.js';
import type { OptimizeResult, PromptOptimizerService } from './optimizer.js';
/** Tool-facing description for `prompt_optimize`. */
export declare const PROMPT_OPTIMIZE_DESCRIPTION: string;
/** Render the canonical value to model-facing text (pure, replay-safe). */
export declare function renderOptimizeResult(value: OptimizeResult): ContentBlock[];
/**
 * Register the `prompt_optimize` tool and its system-prompt guidance. Both
 * registrations are effect-scoped and unregister on plugin dispose.
 */
export declare function registerPromptOptimizeTool(ctx: Context, config: Config, service: PromptOptimizerService): void;
