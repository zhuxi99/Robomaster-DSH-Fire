/** Fusion 360 — planned external executor. */
import type { CadConnector } from './types.js';
export declare const FUSION360_CONNECTOR: CadConnector;
