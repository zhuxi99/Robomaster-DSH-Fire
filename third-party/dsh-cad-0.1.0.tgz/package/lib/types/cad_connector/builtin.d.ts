/** The built-in modeling kernel: opencascade.js (WASM) in a worker, rendered with WebGL/three.js. */
import type { CadConnector } from './types.js';
export declare const BUILTIN_CONNECTOR: CadConnector;
