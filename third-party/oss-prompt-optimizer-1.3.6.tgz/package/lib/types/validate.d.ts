/** The four required section headings, in canonical order. */
export declare const REQUIRED_SECTIONS: readonly ["Role", "Task", "Context", "Format"];
/** Whether every required section heading appears in `text`. */
export declare function hasAllSections(text: string): boolean;
/**
 * Whether `text` already looks like an optimized prompt: all four required
 * sections present under their canonical English heading OR a Chinese-variant
 * heading (`## 角色` / `## 任务` / `## 背景` / `## 输出` etc.). Used by the
 * `skipIfAlreadyOptimized` pass-through so a re-optimization of an
 * already-structured prompt (in either language) is skipped.
 */
export declare function hasOptimizedSections(text: string): boolean;
/** Whether any of the four section headings appears in `text`. */
export declare function hasSectionHeadings(text: string): boolean;
/**
 * The body text of one section (everything between its heading and the next
 * heading or end), trimmed.
 */
export declare function sectionBody(text: string, section: string): string;
/**
 * Whether every required section is present AND its body contains at least
 * `minChars` non-whitespace characters. `minChars <= 0` falls back to the
 * heading-only check.
 */
export declare function hasValidSections(text: string, minChars: number): boolean;
/**
 * Whether the whole text contains at least `minChars` non-whitespace
 * characters (the plain-style content floor).
 */
export declare function hasSubstantialContent(text: string, minChars: number): boolean;
/**
 * Whether a plain-style output is acceptable: at least `minChars`
 * non-whitespace characters AND no four-section headings (the plain style
 * forbids headings; this is the enforcement backstop for the meta-prompt rule).
 */
export declare function hasPlainOutput(text: string, minChars: number): boolean;
/** Stable failure message when a plain-style prompt is empty or too short. */
export declare function thinOutputMessage(minChars: number): string;
/** Stable failure message when a plain-style output carries section headings. */
export declare function plainHeadingsMessage(): string;
/** Reject empty / non-string input loudly (the tool argument contract). */
export declare function assertInput(input: unknown): asserts input is string;
/** Bound an over-long instruction so the call stays within budget. */
export declare function truncateInput(input: string, maxChars: number): string;
/**
 * Heuristic token estimate without a tokenizer: CJK and other wide code points
 * count as one token each, ASCII runs count as one token per four characters.
 * Used as a fallback when the harness `tokenMeter` service is unavailable.
 */
export declare function estimateTokens(text: string): number;
/**
 * Truncate `text` to the longest prefix whose estimated token count is within
 * `maxTokens` (binary search over the cut point), appending `marker` when cut.
 * Shared by the instruction guard (`truncateByTokens`) and the conversation
 * context gatherer — both bound a text block by a token budget.
 * @param text - the text to bound.
 * @param maxTokens - the token budget; `<= 0` disables the guard.
 * @param estimate - token estimator (harness tokenMeter or a heuristic).
 * @param marker - the cut-marker line appended after the truncated prefix.
 */
export declare function truncateToTokenBudget(text: string, maxTokens: number, estimate: (text: string) => number, marker: string): string;
/**
 * Truncate `input` to the longest prefix whose estimated token count is within
 * `maxTokens` (binary search over the cut point). Appends a marker when cut.
 * @param input - the text to bound.
 * @param maxTokens - the token budget; `<= 0` disables the guard.
 * @param estimate - token estimator (harness tokenMeter or a heuristic).
 */
export declare function truncateByTokens(input: string, maxTokens: number, estimate: (text: string) => number): string;
/** Stable failure message when the model omits one or more sections. */
export declare const INCOMPLETE_SECTIONS_MESSAGE = "optimized prompt is missing one or more required sections (## Role / ## Task / ## Context / ## Format)";
/** Stable failure message when a section body is empty or too short. */
export declare function thinSectionsMessage(minChars: number): string;
/** Structured diagnosis of a section-style output (missing / too-thin sections). */
export interface SectionDiagnosis {
    /** Required section names whose heading is absent, in canonical order. */
    missing: string[];
    /** Sections whose body has fewer than `minChars` meaningful characters. */
    thin: {
        name: string;
        chars: number;
    }[];
}
/**
 * Diagnose a section-style output: which required sections are missing and
 * which are present but too thin. Heading-only when `minChars <= 0` (thin is
 * then always empty). Pure — used to build diagnosis-driven retry feedback.
 */
export declare function diagnoseSections(text: string, minChars: number): SectionDiagnosis;
