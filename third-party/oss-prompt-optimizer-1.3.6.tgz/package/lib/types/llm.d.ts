import type { BlockAssembler, FinishReason } from '@deepseek-ai/dsh-llm';
import { OptimizeError } from './errors.js';
/**
 * Raised when a model call stops because the output hit `maxTokens`.
 * `partial` carries the text assembled before truncation — the resume
 * (断点续传) path appends it to the accumulated output and asks the next
 * call to continue from there. Re-exported from `./optimizer.js` (and
 * `index.js`) to keep the public API surface unchanged.
 */
export declare class MaxTokensError extends OptimizeError {
    /** The text produced before the `max-tokens` finish (empty when none). */
    readonly partial: string;
    constructor(partial?: string);
}
/** Translate a terminal finish reason into a thrown error, or accept `stop`. Pure function. */
export declare function finishToError(finish: FinishReason): Error | undefined;
/** Concatenate the text blocks of a finished stream assembler. Pure function. */
export declare function assembleStream(assembler: BlockAssembler): string;
