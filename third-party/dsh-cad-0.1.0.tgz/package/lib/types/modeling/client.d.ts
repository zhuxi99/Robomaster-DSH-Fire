export interface WorkerMesh {
    name: string;
    positions: Float32Array;
    normals: Float32Array;
    indices: Uint32Array;
    vertexCount: number;
    triangleCount: number;
}
export interface OpResult {
    bodyId?: string;
    name?: string;
    removed?: string[];
    edges?: number;
    mesh?: WorkerMesh;
    meshes?: Array<WorkerMesh & {
        bodyId: string;
    }>;
    bytes?: ArrayBuffer;
    volume?: number;
    deleted?: string;
    cleared?: boolean;
}
export type ModelOp = {
    kind: 'create_prim';
    bodyId: string;
    prim: string;
    params?: Record<string, unknown>;
    name?: string;
} | {
    kind: 'extrude_profile';
    bodyId: string;
    points: number[];
    height?: number;
    base?: number;
    name?: string;
} | {
    kind: 'boolean';
    op: 'fuse' | 'cut' | 'common';
    target: string;
    tools: string[];
} | {
    kind: 'fillet';
    target: string;
    radius: number;
} | {
    kind: 'transform';
    target: string;
    translate?: [number, number, number];
    rotate?: [number, number, number];
    mirror?: [number, number, number];
} | {
    kind: 'tessellate_all';
} | {
    kind: 'export';
    target: string;
    format: 'step' | 'stl';
} | {
    kind: 'volume';
    target: string;
} | {
    kind: 'delete';
    target: string;
} | {
    kind: 'reset';
};
export interface ModelClient {
    /** Run one modeling operation on this client's worker. */
    run(op: ModelOp, timeoutMs?: number): Promise<OpResult>;
    /** Terminate the worker and fail any in-flight jobs. */
    dispose(): void;
}
export declare function createModelClient(): ModelClient;
/** Run one modeling operation on the shared session worker. */
export declare function runModelOp(op: ModelOp, timeoutMs?: number): Promise<OpResult>;
/** Current reset epoch of the shared worker (see above). */
export declare function workerResetEpoch(): number;
/** Test/Dev helper: hard worker file path (used by the vitest suite). */
export declare function workerEntryPath(): string;
