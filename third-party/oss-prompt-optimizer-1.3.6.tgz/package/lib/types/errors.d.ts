/**
 * Machine-readable error codes for the prompt-optimizer capability. Every
 * failure path — the loud `OptimizeError` throws and the graceful
 * `OptimizeResult.errorCode` fallback field — shares this vocabulary so
 * callers (commands, tools, other plugins) can react programmatically
 * instead of matching on message text.
 */
/** Stable, typed error-code vocabulary. */
export declare const OptimizeErrorCode: {
    /** The instruction was empty or not a string. */
    readonly EMPTY_INPUT: "EMPTY_INPUT";
    /** No model route could be resolved (incomplete config pair / no default model). */
    readonly NO_MODEL_ROUTE: "NO_MODEL_ROUTE";
    /** The per-call deadline elapsed before the model call finished. */
    readonly TIMEOUT: "TIMEOUT";
    /** The model output hit `maxTokens`. */
    readonly MAX_TOKENS: "MAX_TOKENS";
    /** The unified call budget (`maxCalls`) was exhausted. */
    readonly TOO_MANY_CALLS: "TOO_MANY_CALLS";
    /** The output was missing one or more required sections. */
    readonly MISSING_SECTIONS: "MISSING_SECTIONS";
    /** A section body was shorter than `minSectionChars`. */
    readonly THIN_SECTIONS: "THIN_SECTIONS";
    /** A plain-style output was shorter than `minSectionChars`. */
    readonly THIN_OUTPUT: "THIN_OUTPUT";
    /** A plain-style output still carried four-section headings. */
    readonly HEADINGS_IN_PLAIN: "HEADINGS_IN_PLAIN";
    /** The output dropped the instruction's goal or a constraint (situation alignment). */
    readonly GOAL_MISALIGNED: "GOAL_MISALIGNED";
    /** The model unexpectedly requested a tool call. */
    readonly TOOL_CALL: "TOOL_CALL";
    /** The model returned an unrecognized finish reason. */
    readonly UNSUPPORTED_FINISH: "UNSUPPORTED_FINISH";
    /** The model produced no text at all. */
    readonly NO_TEXT: "NO_TEXT";
    /** Any other failure not covered above. */
    readonly UNKNOWN: "UNKNOWN";
};
/** Union of all stable error codes. */
export type OptimizeErrorCode = (typeof OptimizeErrorCode)[keyof typeof OptimizeErrorCode];
/** An error carrying a stable machine-readable code. */
export declare class OptimizeError extends Error {
    readonly code: OptimizeErrorCode;
    constructor(code: OptimizeErrorCode, message: string, options?: ErrorOptions);
}
/** Command-facing Chinese text per error code (stable, caller-rendered). */
export declare const OPTIMIZE_ERROR_TEXT: Record<OptimizeErrorCode, string>;
