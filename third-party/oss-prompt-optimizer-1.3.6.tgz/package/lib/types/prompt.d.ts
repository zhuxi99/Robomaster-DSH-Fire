import { type MetaLanguage } from './meta.js';
import type { PromptExample } from './config.js';
import type { TemplateSet } from './templates.js';
import type { GoalDrift, SituationProfile, SituationProfileLevel } from './situation.js';
/**
 * The per-call inputs the service maps onto the meta-prompt builders. One
 * stable context object keeps the three call sites (optimize / iterate /
 * refine) from each re-translating config fields into builder arguments.
 */
export interface PromptBuildContext {
    outputStyle: 'sections' | 'plain';
    extraInstructions: string | undefined;
    examples: PromptExample[] | undefined;
    metaLanguage: MetaLanguage;
    templates: TemplateSet;
    /** Optional conversation context (background reference only). */
    context?: string;
    /** Suggested output-length cap in tokens (soft guideline; 0/absent disables). */
    maxOutputTokens?: number;
    /** Situation-profile injection budget (`situationProfileLevel`). */
    situationProfileLevel?: SituationProfileLevel;
}
/** Build the system prompt for one `optimize` model call. Pure function. */
export declare function buildOptimizeSystem(ctx: PromptBuildContext, input: string, outputLanguage: string, diagnosis?: string, profile?: SituationProfile): string;
/** Build the system prompt for one `iterate` / `selfRefine` model call. Pure function. */
export declare function buildIterateSystem(ctx: PromptBuildContext, last: string, next: string, outputLanguage: string, diagnosis?: string, profile?: SituationProfile, drift?: GoalDrift): string;
