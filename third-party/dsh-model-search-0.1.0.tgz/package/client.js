window.__ModuleLoader__.load({
  id: 'dsh-model-search',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    const React = require('react')

    function escapeRegExp(value) {
      return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    }

    function matchesQuery(value, query) {
      const terms = query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean)
      if (terms.length === 0) return true
      const pattern = new RegExp(terms.map(escapeRegExp).join('.*'))
      return pattern.test(String(value).toLocaleLowerCase())
    }

    function matchesElement(element, query) {
      const group = element.closest('section[role="group"]')
      const groupName = group?.querySelector('[id]')?.textContent ?? ''
      const modelName = element.querySelector('[class*="modelName"]')?.textContent ?? ''
      const modelId = element.getAttribute('title') ?? ''
      return matchesQuery(`${groupName} ${modelName} ${modelId}`, query)
    }

    function installSearch(menu) {
      if (menu.dataset.dshModelSearch === 'installed') return
      const groups = menu.querySelector('[class*="groups"]')
      if (!groups) return

      const input = document.createElement('input')
      input.type = 'search'
      input.placeholder = '搜索模型或提供方…'
      input.setAttribute('aria-label', '搜索模型或提供方')
      input.dataset.dshModelSearchInput = 'true'
      input.style.cssText = 'width:100%;box-sizing:border-box;margin-bottom:4px;padding:7px 9px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-specific-menu);color:var(--dsw-alias-label-primary);outline:none;'
      groups.parentElement?.insertBefore(input, groups)

      const empty = document.createElement('div')
      empty.textContent = '没有匹配的模型。'
      empty.dataset.dshModelSearchEmpty = 'true'
      empty.style.cssText = 'color:var(--dsw-alias-label-tertiary);padding:10px;font-size:13px;line-height:20px;display:none;'
      groups.parentElement?.insertBefore(empty, groups)

      const update = () => {
        const query = input.value
        let visible = 0
        for (const group of groups.querySelectorAll('section[role="group"]')) {
          let groupVisible = 0
          for (const option of group.querySelectorAll('button[role="menuitemradio"]')) {
            const show = matchesElement(option, query)
            option.hidden = !show
            if (show) groupVisible += 1
          }
          group.hidden = groupVisible === 0
          visible += groupVisible
        }
        empty.style.display = visible === 0 ? '' : 'none'
      }

      input.addEventListener('input', update)
      input.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') event.stopPropagation()
      })
      menu.dataset.dshModelSearch = 'installed'
      menu._dshModelSearchCleanup = () => {
        input.remove()
        empty.remove()
        delete menu.dataset.dshModelSearch
        delete menu._dshModelSearchCleanup
      }
      update()
    }

    function scan() {
      for (const menu of document.querySelectorAll('[role="menu"]')) {
        const label = menu.getAttribute('aria-label') || ''
        if (/模型与推理等级|Model and reasoning effort/i.test(label)) installSearch(menu)
      }
    }

    function SearchOverlay() {
      React.useEffect(() => {
        scan()
        const observer = new MutationObserver(scan)
        observer.observe(document.body, { childList: true, subtree: true })
        return () => {
          observer.disconnect()
          for (const menu of document.querySelectorAll('[data-dsh-model-search="installed"]')) menu._dshModelSearchCleanup?.()
        }
      }, [])
      return null
    }

    const inject = ['slots']
    function apply(ctx) {
      ctx.slots.inject('shell.overlay', () => ctx.slots.register({
        name: 'shell.overlay',
        id: 'dsh-model-search-overlay',
        label: () => 'dsh-model-search'
      }, SearchOverlay))
    }

    module.exports = { apply, inject, matchesQuery }
    return module.exports
  }
})
