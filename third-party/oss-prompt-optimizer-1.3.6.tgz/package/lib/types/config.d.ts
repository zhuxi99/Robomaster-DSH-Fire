import z from '@deepseek-ai/schemastery';
/** One few-shot demonstration injected into the meta-prompt. */
export interface PromptExample {
    /** The raw instruction. */
    input: string;
    /** The expected optimized prompt (four sections). */
    output: string;
}
/**
 * Partial custom role-document skeletons. Missing languages fall back to the
 * built-in templates (`templateId: 'default'`); every provided skeleton must
 * keep its data placeholder(s), the `{{输出结构}}` / `{{自查}}` blocks, and
 * the instruction-is-data guardrail line (see `validateTemplateSet`).
 */
export interface CustomTemplateSet {
    optimizeZh?: string;
    optimizeEn?: string;
    iterateZh?: string;
    iterateEn?: string;
}
/** Complete, validated plugin configuration. */
export interface Config {
    /** Sampling temperature for the optimization call. */
    temperature: number;
    /** Upper bound on generated output tokens. */
    maxTokens: number;
    /** Extra attempts after the first call when the four-section validation fails. */
    maxRetries: number;
    /**
     * Unified per-optimization model-call budget (first call + expansions +
     * validation retries together). Exceeding it degrades to the original
     * instruction with `TOO_MANY_CALLS` — bounds worst-case cost/latency.
     */
    maxCalls: number;
    /** Cap on the raw instruction fed to the model (characters). */
    maxInputChars: number;
    /** Cap on the raw instruction fed to the model (estimated tokens); `<= 0` disables. */
    maxInputTokens: number;
    /** Cooperative per-call timeout budget in milliseconds. */
    timeoutMs: number;
    /**
     * Output language for the optimized prompt. `'auto'` (default) follows the
     * instruction's language; any other non-empty value pins the language.
     */
    outputLanguage: string;
    /**
     * Output style for the optimized prompt. `'plain'` (default) emits a
     * heading-free continuous prompt (fewer tokens); `'sections'` emits the
     * four section headings (## Role / ## Task / ## Context / ## Format).
     */
    outputStyle: 'sections' | 'plain';
    /**
     * Language of the optimizer's role document (the meta-prompt / system
     * prompt). `'auto'` (default) follows each instruction's language (`'中文'`
     * for CJK-dominant input, `'英文'` otherwise); `'中文'`/`'英文'` pins it.
     * This only changes the instructions the optimizer itself follows — the
     * output language of the optimized prompt is controlled by
     * `outputLanguage` independently. Pin-able at runtime via the
     * `/optimizer-language` command (auto | 中文 | 英文).
     */
    metaPromptLanguage: 'auto' | '中文' | '英文';
    /** Whether the auto-optimize hook is enabled (see `autoOptimizePrefix`). */
    autoOptimize: boolean;
    /** Prefix that marks a user message for automatic optimization. */
    autoOptimizePrefix: string;
    /**
     * Optional deployment-specific rules appended to the meta-prompt (e.g.
     * domain requirements or style preferences). Multi-line text allowed.
     */
    extraInstructions?: string;
    /** Optional few-shot demonstrations injected into the meta-prompt. */
    examples?: PromptExample[];
    /**
     * Minimum non-whitespace characters each section body must contain for the
     * four-section validation to pass; `0` disables the content check.
     */
    minSectionChars: number;
    /**
     * Multiplier applied to the effective `maxTokens` when a call finishes with
     * `max-tokens` (a truncated output). The jump expansion (跳档) grows the
     * budget by this factor up to `maxTokensCap`, does NOT consume the retry
     * budget, and resumes from the truncated prefix (断点续传). `1` disables
     * the expansion.
     */
    maxTokenRetryFactor: number;
    /**
     * Hard cap for auto-expanded `maxTokens` (`max-tokens` truncation grows by
     * `maxTokenRetryFactor` up to this value). `<= maxTokens` disables
     * expansion. Default 8000 keeps runaway output bounded.
     */
    maxTokensCap: number;
    /**
     * Temperature increment applied per retry attempt (bounded by 2), giving
     * retries more diversity. `0` disables the bump.
     */
    retryTemperatureStep: number;
    /**
     * When true, an input that already carries the four headings passes through
     * unchanged (no model call — the token-saving default; re-optimizing an
     * already-optimized prompt costs nothing). Recognized under the canonical
     * English headings or their Chinese variants (`## 角色` / `## 任务` /
     * `## 背景` / `## 输出` etc., see `hasOptimizedSections`).
     */
    skipIfAlreadyOptimized: boolean;
    /**
     * When true, a successful optimization runs one optional refinement round:
     * the result is passed through the iteration pipeline with a terse-only
     * instruction and adopted only if it still passes validation and is not
     * longer (5% tolerance). Default `false` — costs one extra model call
     * when enabled; any refinement failure keeps the original result.
     */
    selfRefine: boolean;
    /** When true, the auto-optimize hook optimizes every user text message, not only prefixed ones. */
    autoOptimizeAll: boolean;
    /** When true, the hook's replacement message keeps the original instruction text alongside the optimized prompt. */
    hookIncludeOriginal: boolean;
    /**
     * When true, validated optimization results are cached in memory keyed by
     * the exact request (route + system + truncated instruction + truncated
     * context): a repeat returns the previous result with zero model calls.
     * In-memory only, never persisted (see ADR-008).
     */
    cacheEnabled: boolean;
    /** Max cached results before LRU eviction; `0` disables storage. */
    cacheMaxEntries: number;
    /** Cache TTL in milliseconds; `0` disables expiry. */
    cacheTtlMs: number;
    /**
     * When true, optimization includes recent conversation context (the
     * messages before the instruction, injected as the `{{上下文信息}}` block
     * with the pure-data guardrail). `true` (default) keeps the optimizer aware
     * of the conversation; set `false` to make it blind to it.
     */
    contextAware: boolean;
    /** Maximum number of recent messages gathered as context when `contextAware` is on. */
    contextMaxMessages: number;
    /**
     * Token budget for the gathered context; `<= 0` disables the token guard.
     * The context is truncated to the longest prefix within budget. The lean
     * default keeps context background-sized (most short discussions fit).
     */
    contextMaxTokens: number;
    /**
     * Suggested upper bound for the length of the optimized prompt (in tokens),
     * injected into the role document as a soft guideline — the model aims to
     * stay within it but nothing is rejected or retried when it exceeds. `0`
     * disables the hint. Distinct from `maxTokens` (the hard per-call output
     * cap of the model call).
     */
    outputLengthMaxTokens: number;
    /**
     * Injection budget for the situation profile (`{{情境画像}}` block):
     * `'full'` (default) injects role + goal + constraints (and the iteration
     * drift line), `'minimal'` injects goal/constraints only (no role signals,
     * leaner), `'off'` injects nothing. Only controls the situation block —
     * the `{{任务类型}}` hint is unaffected.
     */
    situationProfileLevel: 'off' | 'minimal' | 'full';
    /**
     * Whether a goal-alignment miss consumes a validation retry (latency
     * optimization P0-2). `true` (default) keeps the situation layer's retry:
     * when the output drops the instruction's goal/constraint and retry budget
     * remains, fold the misalignment into the diagnosis and retry. `false`
     * accepts the structurally-valid output as-is — saves the retry call at
     * the cost of goal fidelity. `optimizationProfile: 'fast'` forces `false`.
     */
    goalAlignmentRetry: boolean;
    /**
     * Latency/speed profile (latency optimization P1-2). `'balanced'` (default)
     * keeps every quality gate (validation retries, goal-alignment retries,
     * self-refine). `'fast'` trades corrective calls for time: validation
     * retries and goal-alignment retries are skipped and `selfRefine` is
     * disabled — the output is accepted after the first structurally-valid
     * attempt, so worst-case latency drops at the cost of more rework.
     */
    optimizationProfile: 'balanced' | 'fast';
    /**
     * Early-stop the stream once the output is structurally valid and enters
     * its tail (latency optimization P1-1). `true` (default) stops consuming
     * tokens when the four sections (or plain content) pass validation and the
     * stream keeps producing little new content — saves tail-token latency
     * without touching the structural checks. `false` always consumes the
     * full stream.
     */
    earlyStop: boolean;
    /**
     * Template set id for the optimizer role documents. `'default'` (the only
     * built-in) uses the shipped skeletons; unknown ids fail the load loudly.
     * Custom skeletons come from `metaPromptTemplate`.
     */
    templateId: string;
    /**
     * Optional custom role-document skeletons (partial sets allowed: missing
     * languages fall back to the built-in ones). Each skeleton must keep its
     * data placeholder(s), the `{{输出结构}}` / `{{自查}}` blocks, and the
     * instruction-is-data guardrail line — violations fail the load loudly.
     */
    metaPromptTemplate?: CustomTemplateSet;
    /** Optional explicit provider route; provider and model must be set together. */
    provider?: string;
    /** Optional explicit model id; provider and model must be set together. */
    model?: string;
}
/**
 * Loader schema: validates configuration and fills defaults at plugin load.
 * Invalid configuration fails the load loudly (harness convention).
 */
export declare const Config: z<Config>;
