/** GstarCAD 3D / 浩辰3D — planned external executor. */
import type { CadConnector } from './types.js';
export declare const GSTARCAD3D_CONNECTOR: CadConnector;
