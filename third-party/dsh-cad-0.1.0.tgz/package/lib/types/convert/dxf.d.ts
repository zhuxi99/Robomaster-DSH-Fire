import type { CadDrawing2D } from '../types.js';
/** Convert DXF text into a 2D drawing. */
export declare function parseDXF(text: string): CadDrawing2D;
