import type { ModelOp } from './client.js';
export interface ModelDoc {
    /** Stable document id; doubles as the viewer scene viewId. */
    docId: string;
    /** Monotonic operation counter; the viewer uses it as a cache-busting version. */
    version: number;
    ops: ModelOp[];
    /** Body display names, kept in the manifest for cad_list without a worker round-trip. */
    bodyNames: Record<string, string>;
}
export declare class ModelDocument {
    readonly root: string;
    doc: ModelDoc;
    constructor(root: string);
    private get directory();
    private get file();
    /** Load the persisted document if one exists. */
    restore(): Promise<void>;
    /** Append an applied operation and persist. */
    record(op: ModelOp, bodyName: {
        bodyId: string;
        name: string;
    } | null): Promise<void>;
    /** Clear the document (cad_new / tests). */
    clear(): Promise<void>;
}
