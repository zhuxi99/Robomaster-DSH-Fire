import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { BinarySceneStore } from '../modeling/bin-store.js';
export interface ModelToolDeps {
    store: BinarySceneStore;
    workspaceRoot: string;
    ensureSceneRoute: () => string | null;
}
/** Build the whole tool family over one document + worker + scene store. */
export declare function createModelTools(deps: ModelToolDeps): ToolDefinition[];
export declare const MODEL_TOOL_NAMES: readonly ["cad_create_prim", "cad_extrude_profile", "cad_boolean", "cad_fillet", "cad_transform", "cad_export", "cad_delete", "cad_volume"];
