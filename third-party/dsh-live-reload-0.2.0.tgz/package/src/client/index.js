/**
 * dsh-live-reload — client half.
 *
 * Renders a "Plugin Refresh / 插件刷新" settings section: shows the booted
 * profile and the last refresh result, and triggers a restart-free
 * composition refresh through the host's `/dsh-live-reload/refresh` route.
 * A successful refresh ALWAYS reloads the page afterwards (a short pause
 * keeps the success result visible) — the host process itself never exits.
 * The unconditional reload is what makes a market hot-install land in the
 * running browser: the page re-fetches the live boot manifest, which already
 * carries the new package's client bundle, so no diff-based
 * "clientGraphChanged" detection is needed (that signal is invisible for
 * market hot-mounts anyway, because the client graph is deduplicated by
 * package name and the hot-mount row already registered the package).
 *
 * The bundle is built by tsdown (see tsdown.config.js) into the
 * `window.__ModuleLoader__.load({ id, factory })` artifact; `react` and
 * `react/jsx-runtime` resolve from the loader's frozen module table. No other
 * plugin package is imported — the UI is plain HTML elements with inline
 * styles, so it works across UI-primitive versions.
 *
 * @module dsh-live-reload/client
 */

import { createElement as h, useEffect, useState } from 'react'

export const name = 'dsh-live-reload'

/** Hard dependency: the client slots service (provided by the ui-slots platform module). */
export const inject = ['slots']

const NS = 'dsh-live-reload'

/** One settings page inside Settings → "Plugin Refresh". */
const SECTION_ID = 'live-reload'

/**
 * Theme-following inline style helpers over the real `--dsw-alias-*` tokens
 * (verified against the client Theme service's token registry — see
 * `@deepseek-ai/dsh-client-ui-theme`). The primary-button pair matches the
 * harness's own `Button.module.css` (`--dsw-alias-button-primary-fill` +
 * `--dsw-alias-label-primary-foreground`), which stays contrast-safe in both
 * color schemes. Fallbacks keep the UI legible while the theme loads.
 */
const styles = {
  card: {
    display: 'flex', flexDirection: 'column', gap: '10px', padding: '14px',
    border: '1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.3))',
    background: 'var(--dsw-alias-bg-layer-1, rgba(128,128,128,.06))',
    borderRadius: '8px', maxWidth: '560px', fontSize: '13px', lineHeight: 1.5,
  },
  row: { display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' },
  button: {
    padding: '6px 14px', borderRadius: '6px', border: '1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.4))',
    background: 'var(--dsw-alias-bg-layer-2, rgba(128,128,128,.12))', cursor: 'pointer', fontSize: '13px',
  },
  primary: {
    padding: '6px 14px', borderRadius: '6px', border: '1px solid transparent',
    background: 'var(--dsw-alias-button-primary-fill, #4a6cf7)',
    color: 'var(--dsw-alias-label-primary-foreground, #fff)', cursor: 'pointer', fontSize: '13px',
  },
  muted: { color: 'var(--dsw-alias-label-secondary, rgba(128,128,128,.85))', fontSize: '12px' },
  list: { margin: 0, paddingLeft: '18px', fontSize: '12px' },
  error: { color: 'var(--dsw-alias-state-error-primary, #d9534f)', fontSize: '12px', whiteSpace: 'pre-wrap' },
}

/** The one-click refresh section body. */
function LiveReloadSection() {
  const [status, setStatus] = useState(null)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)

  const loadStatus = () => {
    fetch('/dsh-live-reload/status')
      .then((res) => res.json())
      .then(setStatus)
      .catch(() => { /* route may be missing while the plugin is mid-boot */ })
  }

  useEffect(() => { loadStatus() }, [])

  const refresh = async () => {
    setBusy(true)
    setError(null)
    setResult(null)
    try {
      const res = await fetch('/dsh-live-reload/refresh', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: '{}',
      })
      const data = await res.json()
      setResult(data)
      loadStatus()
      if (data.ok === true) {
        // 直接刷新：成功后总是整页重载，让新的客户端 bundle 生效（宿主进程
        // 与所有会话保持运行）。不做任何"是否有新增"检测——热安装的插件在
        // 挂载那一刻就已进入实时模块图，页面重载会按最新 boot manifest 拉取。
        // 短暂停留让成功结果可见，再触发重载。
        await new Promise((resolve) => { const t = setTimeout(resolve, 600); t.unref?.() })
        location.reload()
        return
      }
    } catch (caught) {
      setError(String(caught))
    } finally {
      setBusy(false)
    }
  }

  const profile = status?.profile ?? '…'
  const last = status?.last
  const lastText = last !== null && last !== undefined
    ? `${new Date(last.at).toLocaleTimeString()} · ${last.ok ? '✓' : '✗'} (+${last.added.length} −${last.removed.length} ~${last.updated.length})`
    : '—'

  return h('div', { style: styles.card },
    h('div', { style: styles.row },
      h('span', null, '插件刷新 · Plugin Refresh'),
      h('span', { style: styles.muted }, `profile: ${profile}`),
      h('span', { style: styles.muted }, `上次: ${lastText}`),
    ),
    h('div', { style: styles.row },
      h('button', {
        style: styles.primary,
        disabled: busy || status?.refreshing === true,
        onClick: refresh,
      }, busy ? '刷新并重载中…' : '一键刷新插件并重载页面 / Refresh Plugins & Reload'),
    ),
    h('div', { style: styles.muted },
      '提示:手动保存 cordis.patch.yml 后,内置 HMR 会按启动时的 bundle 集合重放;安装过新 bundle 时请再点一次刷新以完整恢复。刷新成功后页面将自动重载以加载新的客户端插件（宿主进程不退出）。'),
    error !== null && h('pre', { style: styles.error }, error),
    result !== null && h(ResultPanel, { result }),
  )
}

/**
 * Renders one refresh result: added / removed / updated rows + errors.
 * Success reloads the page automatically (see `refresh`), so this panel is
 * only fully readable for failures — success shows for a moment before the
 * reload lands.
 */
function ResultPanel({ result }) {
  const ok = result.ok === true
  const lines = []
  if (!ok && Array.isArray(result.errors)) lines.push(`错误 / errors:\n${result.errors.join('\n')}`)
  if (result.added?.length > 0) lines.push(`新增 / added: ${result.added.join(', ')}`)
  if (result.removed?.length > 0) lines.push(`移除 / removed: ${result.removed.join(', ')}`)
  if (result.updated?.length > 0) lines.push(`更新 / updated: ${result.updated.join(', ')}`)
  if (result.updatedOnDisk?.length > 0) {
    lines.push(`磁盘已更新并热加载 / updated-on-disk, hot-loaded: ${result.updatedOnDisk.join(', ')}`)
  }
  if (lines.length === 0) lines.push('无变化 / no changes')

  return h('div', null,
    h('div', { style: { color: ok ? 'var(--dsw-alias-state-success-primary, #3c9d5b)' : 'var(--dsw-alias-state-error-primary, #d9534f)', fontSize: '12px', fontWeight: 600 } },
      ok ? '✓ 已热刷新，即将重载页面 / refreshed live, reloading…' : '✗ 刷新失败 / refresh failed'),
    h('ul', { style: styles.list }, lines.map((line, index) => h('li', { key: index }, line))),
  )
}

/**
 * Cordis client plugin entry: register the settings section.
 * @param {{get(name: string): unknown, effect(cb: () => unknown, label?: string): void}} ctx
 */
export function apply(ctx) {
  const slots = ctx.get('slots')
  if (slots === undefined) return
  ctx.effect(() => slots.inject('settings.section', () => slots.register(
    {
      name: 'settings.section',
      id: SECTION_ID,
      order: 50,
      label: () => '插件刷新 / Plugin Refresh',
    },
    () => h(LiveReloadSection, {}),
  )), `${NS}: settings section`)
}
