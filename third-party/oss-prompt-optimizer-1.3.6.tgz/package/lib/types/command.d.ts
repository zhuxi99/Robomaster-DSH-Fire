import type { Context } from '@deepseek-ai/cordis';
import type { PromptOptimizerService } from './optimizer.js';
/** Stable machine-readable token for the current role-document language mode. */
export declare function metaLanguageToken(language: 'auto' | 'zh' | 'en'): string;
/**
 * Register the `/optimize`, `/auto-optimize`, `/optimizer-language` and
 * `/optimize-stats` commands. The browser client drives the input-box buttons
 * through the already-generated `commands` Remote namespace
 * (`ctx.remote.commands.execute(sessionId, ...)`) — the one client→host RPC
 * path that ships with strict descriptors and is guaranteed to be claimed by
 * the host gateway (custom `@Remote` namespaces require SRC discovery, which
 * is unreliable in deployed compositions).
 *
 * Effect-scoped: the registrations are removed on plugin dispose.
 */
export declare function registerOptimizeCommand(ctx: Context, service: PromptOptimizerService): void;
