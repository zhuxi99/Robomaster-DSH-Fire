import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { BinarySceneStore } from '../modeling/bin-store.js';
export interface FreeCadToolDeps {
    store: BinarySceneStore;
    workspaceRoot: string;
    ensureSceneRoute: () => string | null;
}
/**
 * LLM callers emit op shapes liberally. Normalize the common variants onto
 * the canonical op shape before validation/execution:
 *  - {op:"cut", target, tools}              → {kind:"boolean", op:"cut", ...}
 *  - {op:"create_prim", kind:"box", dx:...} → {kind:"create_prim", prim:"box", params:{dx:...}}
 *  - {kind:"create_prim", prim, dx:...}     → params folded in
 */
export declare function normalizeFreeCadSteps(raw: unknown[]): Array<Record<string, unknown>>;
export declare function createFreeCadTool(deps: FreeCadToolDeps): ToolDefinition;
