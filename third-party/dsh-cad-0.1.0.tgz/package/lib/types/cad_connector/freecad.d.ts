/** FreeCAD — external executor, live via the local console binary. */
import type { CadConnector } from './types.js';
export declare const FREECAD_CONNECTOR: CadConnector;
