/** Onshape — planned external executor, cloud-native. */
import type { CadConnector } from './types.js';
export declare const ONSHAPE_CONNECTOR: CadConnector;
