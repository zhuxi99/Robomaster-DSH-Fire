/** ZW3D / 中望3D — planned external executor. */
import type { CadConnector } from './types.js';
export declare const ZW3D_CONNECTOR: CadConnector;
