import type { IncomingMessage, ServerResponse } from 'node:http';
import type { SceneStore } from './store.js';
import type { BinarySceneStore } from './modeling/bin-store.js';
export declare const SCENE_ROUTE_PATH = "/dsh-cad/scene";
export declare const BIN_ROUTE_PATH = "/dsh-cad/bin";
export declare const DEMO_SCENE_ROUTE_PATH = "/dsh-cad/demo-scene";
/** The built-in demo examples (packaged as lib/demo-<part>.brep). */
export declare const DEMO_PARTS: readonly ["bracket", "flange", "shaft"];
export type DemoPart = (typeof DEMO_PARTS)[number];
/** Register the scene route on the shared HTTP server. Returns a disposer. */
export declare function registerSceneRoute(server: {
    register: (route: SceneRoute) => () => void;
}, store: SceneStore): () => void;
interface SceneRoute {
    kind: 'prefix' | 'exact';
    path: string;
    handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;
}
/** Register the binary scene route. Returns a disposer. */
export declare function registerBinRoute(server: {
    register: (route: SceneRoute) => () => void;
}, store: BinarySceneStore): () => void;
/** Register the demo-scene route: GET /dsh-cad/demo-scene?part=<bracket|flange|shaft>. */
export declare function registerDemoRoute(server: {
    register: (route: SceneRoute) => () => void;
}): () => void;
export type { SceneRoute };
