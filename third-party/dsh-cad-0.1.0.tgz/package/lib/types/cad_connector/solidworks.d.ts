/** SolidWorks — planned external executor. */
import type { CadConnector } from './types.js';
export declare const SOLIDWORKS_CONNECTOR: CadConnector;
