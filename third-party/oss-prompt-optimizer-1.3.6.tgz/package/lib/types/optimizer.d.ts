import { Service, type Context } from '@deepseek-ai/cordis';
import { Config, type Config as ConfigType } from './config.js';
import type { OptimizeErrorCode as OptimizeErrorCodeType } from './errors.js';
import { type MetaLanguage } from './meta.js';
export { MaxTokensError } from './llm.js';
/** Stable capability-owned timeout reason code for optimization calls. */
export declare const PROMPT_OPTIMIZER_TIMEOUT_CODE = "PROMPT_OPTIMIZER_TIMEOUT";
/** Optional per-call controls (override the plugin config for one call). */
export interface OptimizeOptions {
    /** Cancellation forwarded into the model call. */
    signal?: AbortSignal;
    /** Per-call temperature override. */
    temperature?: number;
    /** Per-call maxTokens override. */
    maxTokens?: number;
    /** Per-call output-language override. */
    outputLanguage?: string;
    /**
     * Optional conversation context (background reference only). The caller
     * gathers and bounds it (e.g. `gatherConversationContext`); the service
     * injects it into the meta-prompt as the `{{上下文信息}}` block. Absent
     * (or empty) keeps the optimizer blind to the conversation.
     */
    context?: string;
    /**
     * Optional cache-namespace scope (e.g. a session id). Included in the cache
     * key so cache hits never cross scopes. Absent → a global cache namespace
     * (the key already contains the full request, so identical requests share).
     */
    cacheScope?: string;
    /**
     * Optional session id (P2 会话级目标注册表): enables the per-session goal
     * registry — goals/constraints stated in earlier calls of the same session
     * carry forward when the current instruction does not restate them
     * (fallback semantics, see `mergeGoals`). The merged goal is injected into
     * the situation block and used by the goal-alignment check. Absent → no
     * registry participation.
     */
    sessionId?: string;
}
/** The service result: the optimized prompt, or a clear fallback. */
export interface OptimizeResult {
    /** The optimized prompt on success, the original instruction on failure. */
    prompt: string;
    /** Whether the four-section validation passed. */
    optimized: boolean;
    /** Failure explanation present when `optimized` is false. */
    error?: string;
    /** Stable machine-readable error code (present whenever `optimized` is false). */
    errorCode?: OptimizeErrorCodeType;
    /** Attempts consumed before success or giving up (0-based). */
    retries: number;
    /** Per-section breakdown of a successful optimized prompt (sections style only). */
    sections?: {
        name: string;
        content: string;
    }[];
    /** Estimated token count of the optimized prompt (successful results only). */
    outputTokens?: number;
}
/**
 * The `promptOptimizer` service (class-form plugin): optimizes raw
 * instructions into professional four-section prompts through the harness
 * `llm` service, and registers the `prompt_optimize` tool, the `/optimize`
 * command, and the auto-optimize hook. Configuration is validated by the
 * loader; the model route comes from `agentDefaultModel` unless the plugin
 * config supplies an explicit provider/model pair.
 */
export declare class PromptOptimizerService extends Service {
    static inject: string[];
    static Config: import("@deepseek-ai/schemastery").default<Config>;
    private readonly config;
    /** The active role-document template set (resolved and validated at construction). */
    private readonly templates;
    /** Runtime override for "optimize every message" (flipped by `/auto-optimize`). */
    private runtimeAutoOptimizeAll;
    /**
     * Runtime override for the role-document language (flipped by the
     * `/optimizer-language` command and the input-box language button).
     * `undefined` falls back to the configured `metaPromptLanguage`.
     */
    private runtimeMetaPromptLanguage;
    /** In-memory validated-result cache (LRU + TTL, see ADR-008). */
    private readonly cache;
    /** Lightweight run statistics (观测, roadmap 要优化的功能 #2). */
    private readonly stats;
    constructor(ctx: Context, config: ConfigType);
    /** Whether the auto-optimize hook should optimize every user text message. */
    isAutoOptimizeAll(): boolean;
    /** Set the runtime "optimize every message" override. */
    setAutoOptimizeAll(value: boolean): void;
    /**
     * The active role-document language mode: runtime override (pinned via
     * `/optimizer-language`), else the configured `metaPromptLanguage`.
     * `'auto'` means each call resolves the language from its input.
     */
    getMetaPromptLanguage(): 'auto' | MetaLanguage;
    /** Resolve the role-document language for one call: `'auto'` detects it from `input`. */
    resolveMetaLanguage(input: string): MetaLanguage;
    /** Set the runtime role-document language override; `'auto'` clears it (fall back to config). */
    setMetaPromptLanguage(language: 'auto' | MetaLanguage): void;
    /** Whether context-aware optimization is enabled by config. */
    isContextAware(): boolean;
    /** The configured context-gathering bounds (messages / tokens). */
    contextConfig(): {
        maxMessages: number;
        maxTokens: number;
    };
    /** The per-call prompt-build context (config fields + resolved language + optional context). */
    private promptContext;
    /**
     * Goal-misalignment feedback injected into the next retry's `{{诊断反馈}}`
     * block (situation layer P0). Lists the goal/constraint labels that the
     * output lost, in the role-document language.
     */
    private goalDiagnosis;
    /** TTL for a session's registered goal (P2 会话级目标注册表). */
    private static readonly GOAL_TTL_MS;
    /** Cap on registered sessions; the oldest entry is evicted beyond it. */
    private static readonly GOAL_REGISTRY_MAX;
    /** Per-session registered goals: sessionId → goal + last-seen timestamp. */
    private readonly goalRegistry;
    /**
     * Merge the session's registered goal into the current instruction's
     * profile and refresh the registry (P2). Fallback semantics — the current
     * instruction wins whenever it states something; previously-stated goals
     * and constraints carry forward only when the current call leaves them
     * unstated. Expired entries are dropped on access.
     */
    private mergeSessionGoal;
    /**
     * Cache key for one request: FNV-1a over what is actually fed to the model
     * (provider + model + the no-diagnosis system prompt + truncated input +
     * truncated context + optional scope). Sampling/budget knobs (temperature,
     * maxTokens…) intentionally do NOT participate — an identical request gets
     * the same validated result regardless of them.
     */
    private cacheKeyFor;
    /** Fire `optimize:start`; a throwing listener must never break the pipeline. */
    private emitStart;
    /** Fire `optimize:success` or `optimize:failure` based on the outcome. */
    private emitCompleted;
    /** Snapshot of the run statistics (观测; copy so callers cannot mutate). */
    getStats(): {
        runs: number;
        success: number;
        failed: number;
        cached: number;
        totalDurationMs: number;
        maxDurationMs: number;
        lastOutputTokens: number;
    };
    /** Estimate the token count of one text (harness tokenMeter, heuristic fallback). */
    private estimateTextTokens;
    /** Parse the four sections out of a successful optimized prompt. */
    private sectionsOf;
    /**
     * Optimize one raw instruction. Never throws for a model-quality failure:
     * when the model cannot produce all four sections within the retry budget,
     * the original instruction is returned with an explanation.
     */
    optimize(rawInput: string, options?: OptimizeOptions): Promise<OptimizeResult>;
    /**
     * Iterate on a previously optimized prompt with a new requirement. Runs the
     * same generation pipeline as `optimize` but frames the model call around
     * the previous result. Never throws for a model-quality failure: the
     * previous result is returned unchanged with an explanation instead.
     */
    iterate(lastOptimized: string, instruction: string, options?: OptimizeOptions): Promise<OptimizeResult>;
    /**
     * Shared generation pipeline: resolve the route, then retry the model call
     * until the output passes validation or the retry budget is exhausted. A
     * failed run returns `fallbackPrompt` (the raw instruction for `optimize`,
     * the previous result for `iterate`) with an explanation and error code.
     */
    private runPipeline;
    /**
     * One optional refinement round after a successful optimization
     * (`selfRefine`): re-run the iteration pipeline with the terse-only
     * instruction, then adopt the result only if it still passes validation
     * and is not longer than the original (5% tolerance). Any failure is
     * swallowed — the original result stands.
     */
    private refineOnce;
    /**
     * One model call: stream with the pre-built system prompt and return the
     * text. With `continueFrom` (断点续传), the user message asks the model to
     * continue from the truncated prefix instead of regenerating it — only the
     * continuation text is returned and the caller merges it.
     */
    private generateOnce;
    /** Resolve the model route: explicit config pair, else the harness default. */
    private resolveRoute;
}
export default PromptOptimizerService;
